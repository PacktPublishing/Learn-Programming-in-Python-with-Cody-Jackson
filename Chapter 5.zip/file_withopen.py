with open("afile.txt") as this_file:
    read_data = this_file.read()
    print(read_data)