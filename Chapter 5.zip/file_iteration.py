for line in open("afile.txt"):
    print(line)

for line in open("afile.txt"):
    print(line, end="")