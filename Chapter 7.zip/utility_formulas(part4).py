if __name__ == "__main__":
    print(gravity_flow_rate(2, 0.6))
    print(static_press(150))
    print(press_to_head(65.0))
    print(head_to_press(150))
