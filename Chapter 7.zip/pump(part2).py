import sys
sys.path.extend(["/home/cody/PycharmProjects/VirtualPLC"])
import math
import numbers
from Utilities import utility_formulas

GRAVITY = 9.81  # m/s^2
