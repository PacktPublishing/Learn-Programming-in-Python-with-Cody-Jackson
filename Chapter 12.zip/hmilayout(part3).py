    def populate(self):
        # Make dictionaries to populate table
        tank_properties1 = {}
        tank_properties2 = {}

        valve_properties1 = {}
        valve_properties2 = {}
        valve_properties3 = {}
        valve_properties4 = {}
        valve_properties5 = {}
        valve_properties6 = {}
        valve_properties7 = {}

        pump_properties1 = {}
        pump_properties2 = {}
