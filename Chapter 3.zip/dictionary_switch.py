choice = "spam"
print({
    "chicken": 4.25,
    "ham": 6.50,
    "spam": 3.25,
    "bacon": 5.35}
    [choice])