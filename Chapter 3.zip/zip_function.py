tup1 = (1, 2, 3)
tup2 = (4, 5, 6)
tup3 = (7, 8, 9)
# print() required for program functionality
print(list(zip(tup1, tup2, tup3)))
