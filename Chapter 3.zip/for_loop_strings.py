s = "spam, bacon, and eggs"
t = (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
for char in s:
    print(char, end="")

for num in t:
    print(num, end=",")