i = 0
while i < 10:
    print("{} is less than 10.".format(i))
else:
    print("{} is equal to 10.".format(i))
