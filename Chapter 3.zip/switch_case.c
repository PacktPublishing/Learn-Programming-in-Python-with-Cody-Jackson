switch (grade) {
  case "A":  
		printf("Outstanding!");
        break;
  case "B":
		printf("Good job!");
        break;
  case "C":
		printf("Satisfactory performance.");
        break;
  case "D":  
		printf("You should try harder.");
        break;
  case "F":
		printf("You failed.");
		break;
  default: 
		printf("Invalid grade");
}
