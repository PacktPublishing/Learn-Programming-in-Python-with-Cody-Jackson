keys = (1, 2, 3)
values = ["Sir Gawain", "Sir Robin", "Tim the Enchanter"]
combine = dict(zip(keys, values))
print(combine)
