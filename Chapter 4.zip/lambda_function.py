def func(a, b, c):
    return a*b*c

lam_func = lambda a, b, c: a*b*c
