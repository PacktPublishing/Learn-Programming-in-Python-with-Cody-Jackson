class Knight:
    def setName(self, name):
        self.name = name
    def display(self):
        print(self.name)
