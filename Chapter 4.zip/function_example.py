def square_num(x):
    return x * x

for x in range(1, 10):
    print(square_num(x))
    