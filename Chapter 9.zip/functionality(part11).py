# Gate valve 9
def gate9_open():
    ffc.gate9.open()

def gate9_close():
    ffc.gate9.close()

# Gate valve 10
def gate10_open():
    ffc.gate10.open()

def gate10_close():
    ffc.gate10.close()
