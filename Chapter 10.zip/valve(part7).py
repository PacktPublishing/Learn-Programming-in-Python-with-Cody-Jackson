        :return: Indication of whether the valve is open or closed.
        :rtype: str
        """

    def turn_handle(self, new_position):
        """Change the status of the valve.
        
        :param new_position: New valve position

        :return: Update valve position
        """
