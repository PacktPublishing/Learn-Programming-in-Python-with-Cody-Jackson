inventory = {
    ("tomato", "red"): 48,
    ("tomato", "green"): 13,
    ("carrot", "orange"): 35,
    ("carrot", "purple"):8,
    ("spam", "regular"): 24,
    ("spam", "bacon"): 3,
}

quantity = inventory["tomato", "red"]
print(quantity)
