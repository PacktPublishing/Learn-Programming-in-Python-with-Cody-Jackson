    _4d6 = multiDie(4,1)   #4d6
    print("\n4d6 = ", _4d6, end=' ')
    _1d10 = multiDie(1,2)   #1d10
    print("\n1d10 = ", _1d10, end=' ')
    _2d10 = multiDie(2,2)   #2d10
    print("\n2d10 = ", _2d10, end=' ')
    _3d10 = multiDie(2,2)   #3d10
    print("\n3d10 = ", _3d10, end=' ')
    _d100 = multiDie(1,3)   #d100
    print("\n1d100 = ", _d100) 
