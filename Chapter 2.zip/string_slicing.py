S = "spam"
# print() required for program functionality
print(S[1:3], S[1:], S[:-1])
