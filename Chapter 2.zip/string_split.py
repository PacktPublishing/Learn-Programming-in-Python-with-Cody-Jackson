split_me = "My wife hates spam."
split_me.split()

split_me_too = "1, 2, 3"
split_me_too.split(",")
