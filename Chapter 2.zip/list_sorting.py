l = ["Sir Galahad", "Sir Lancelot", "King Arthur", "Sir Robin", "black knight", "rabbit"]
l.sort()
l.sort(key=str.lower)
l.sort(reverse=True)
