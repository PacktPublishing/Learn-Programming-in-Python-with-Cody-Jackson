my_funct()

print("Outside function, var1: {}".format(var1))
print("Outside function, var2: {}".format(var2))
print("Outside function, var3: {}".format(var3))
