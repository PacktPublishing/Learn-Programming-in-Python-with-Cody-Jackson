seq_string = ("A1", "B2", "C3")
"-".join(seq_string)
print("-".join(seq_string))
