first_phrase = "{0}, {1}, and {2}".format("chicken", "beef", "spam")
second_phrase = "{smell}, {color}, and {flavor}".format(smell="sweet", color="red", flavor="sugary")
third_phrase = "{}, {}, and {}".format("spam", "spam", "more spam")
