index_me = "spam me"
# print() function required for program operation
print(index_me[0], index_me[-2])