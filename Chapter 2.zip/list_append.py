l = [1, 2, 3]
l.append("number")
l.insert(2, 75)

