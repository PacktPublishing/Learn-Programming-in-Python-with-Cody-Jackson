l1 = ["spam", "Spam", "SPAM"]
l1[1] = "eggs"
l1[0:2] = ["eat", "more"]
del l1[0]