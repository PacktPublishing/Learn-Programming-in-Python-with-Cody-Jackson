insect = "cricket"
bird = "African swallow"
insect, bird = bird, insect
# print() required for program functionality
print(insect)
print(bird)
