myjob = "lumberjack"
for char in myjob:
    print(char)

for char in myjob:
    print(char, end="")