bird = "parrot"
d = 1
print("That is %d dead %s!" % (d, bird))