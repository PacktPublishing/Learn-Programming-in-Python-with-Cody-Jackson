string1 = "1 2 3"
string2 = "A B C"
string3 = string1 + string2
string4 = string2.join(string1)
print(string3)
print(string4)
